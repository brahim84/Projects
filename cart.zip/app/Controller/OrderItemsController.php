<?php
class OrderItemsController extends AppController {

	public $scaffold = 'admin';

}
