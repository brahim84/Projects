$(document).ready(function(){
	$('#flash_msg').delay(5000).fadeOut('slow');
});

